package megaListaDinamicaPackage;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Lista {
	
	private static int totalMListas = 0;
	private int index=0; //construtor + criarLista()
	private ArrayList<ArrayList<String>> megaLista = new ArrayList<>();
	private ArrayList<String> nomesListas = new ArrayList<String>();
	private ArrayList<Boolean> vaiNumerarListas = new ArrayList<Boolean>();
	
	
	public Lista(){
		
		totalMListas++;
		
		int contador = Integer.parseInt(JOptionPane.showInputDialog("<html><u>MEGA LISTA " + totalMListas
																	+ "</u><br>Quantas listas você deseja fazer?</html>"));
		
		for(index = 0; index < contador; index++) {
			nomesListas.add(nomearLista());
			vaiNumerarListas.add(numerarLista());
			megaLista.add(criarLista());
		}
		
	}
	
	
	public boolean numerarLista() {
		
		boolean bool;
		
		while(true) {
			
			String input = JOptionPane.showInputDialog("<html><u>MEGA LISTA " + totalMListas 
														+ "</u><br>Você deseja numerar a lista "+(index+1)+"?<br>"
														+ "Digite <i>SIM</i> ou <i>NÃO</i></html>");
			
			if(input.toUpperCase().equals("SIM")) {
				bool = true;
				break;
			} else if(input.toUpperCase().equals("NAO") || input.toUpperCase().equals("NÃO")) {
				bool = false;
				break;
			}	
		}
		
		return bool;
	}
	
	
	public String nomearLista() {
		
		String nomeLista = JOptionPane.showInputDialog("<html><u>MEGA LISTA " + totalMListas 
														+ "</u><br>Escolha um nome para a lista </html>" + (index+1));	
		return nomeLista;
		
	}
	
	
	public ArrayList<String> criarLista() {
		
		ArrayList<String> lista = new ArrayList<String>();
		
		while(true) {
			String input = JOptionPane.showInputDialog("<html><u>MEGA LISTA " + totalMListas
														+ "</u><br>LISTA " + (index+1)
														+ ": " + nomesListas.get(index)
														+ "<br><br>DIGITE <i>SAIR</i> PARA FECHAR A LISTA"
														+ "<br><br>Digite um elemento da lista:</html>");
			if(input.toUpperCase().equals("SAIR")) {
				break;
			} else if(!input.isEmpty()) {
				lista.add(input);
			}
			
			
		}
		
		return lista;
	}
	
	
	public String toString() {
		
		String stringPlural = "S"; //gramática
		if(this.megaLista.size() == 1) {
			stringPlural = "";
		}
		

		String listString =
				"A MEGA LISTA " + totalMListas 
				+" CONTÊM "	+ this.megaLista.size() 
				+ " LISTA" + stringPlural + ":";
		

		for(int i = 0; i < this.megaLista.size(); i++) {
			
			listString += "\n\nLISTA "+(i+1)+": " + nomesListas.get(i); //Cabeçalho da sub-lista
			
			for(int j = 0; j < this.megaLista.get(i).size(); j++) {
				
				if(vaiNumerarListas.get(i)) {
					listString += "\n"+(j+1)+")"+this.megaLista.get(i).get(j) + " ";
				} else {
					listString += "\n-"+this.megaLista.get(i).get(j) + " ";
				}

				
			}//j
			
		}//i
		
		return listString;
	}

}
