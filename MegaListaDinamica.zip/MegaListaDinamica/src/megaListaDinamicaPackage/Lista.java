package megaListaDinamicaPackage;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Lista {
	
	private static int totalMListas = 0;
	private int index=0; //construtor + criarLista()
	private ArrayList<ArrayList<String>> megaLista = new ArrayList<>();
	
	public Lista(){
		
		totalMListas++;
		
		int contador = Integer.parseInt(JOptionPane.showInputDialog("MEGA LISTA " + totalMListas
																	+ "\nQuantas listas você deseja fazer?"));
		
		for(index = 0; index < contador; index++) {
			megaLista.add(criarLista());
		}
		
	}
	
	//sem arg. pra index?
	//User pode requisitar criarLista() avulsamente
	public ArrayList<String> criarLista() {
		
		ArrayList<String> lista = new ArrayList<String>();
		
		while(true) {
			String input = JOptionPane.showInputDialog("MEGA LISTA " + totalMListas
														+ "\nLISTA " + (index+1)
														+ "\nDIGITE SAIR PARA FECHAR A LISTA"
														+ "\n\nDigite um elemento da lista:");
			if(input.toUpperCase().equals("SAIR")) {
				break;
			} else if(!input.isEmpty()) {
				lista.add(input);
			}
			
			
		}
		
		return lista;
	}
	
	
	public String toString() {
		
		String stringPlural = ""; //gramática
		if(this.megaLista.size()>1) {
			stringPlural = "S";
		}
		

		String listString = 
				"\n==================================\n"
				+ "\nA MEGA LISTA " + totalMListas 
				+" CONTÊM "	+ this.megaLista.size() //Tamanho da mega lista = número de sub-listas 
				+ " LISTA"+ stringPlural + ":";
		

		for(int i = 0; i < this.megaLista.size(); i++) {
			
			listString += "\n\nLISTA "+(i+1); //Cabeçalho da sub-lista
			
			for(int j = 0; j < this.megaLista.get(i).size(); j++) {
				
				listString += "\n-"+this.megaLista.get(i).get(j) + " ";
				
			}//j
			
		}//i
		
		return listString; //Retorna string com termos + formatação
	}

}
