package megaListaDinamicaPackage;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Lista {
	
	private static int totalMListas = 0;
	private int index=0; //construtor + criarLista()
	private ArrayList<ArrayList<String>> megaLista = new ArrayList<>();
	private ArrayList<String> nomesListas = new ArrayList<String>();
	private ArrayList<Boolean> vaiNumerarListas = new ArrayList<Boolean>();
	
	
	public Lista(){
		
		totalMListas++;
		
		int contador = Integer.parseInt(JOptionPane.showInputDialog("MEGA LISTA " + totalMListas
																	+ "\nQuantas listas você deseja fazer?"));
		
		for(index = 0; index < contador; index++) {
			nomesListas.add(nomearLista());
			vaiNumerarListas.add(numerarLista());
			megaLista.add(criarLista());
		}
		
	}
	
	
	public boolean numerarLista() {
		
		boolean bool;
		
		while(true) {
			
			String input = JOptionPane.showInputDialog("Você deseja numerar a lista?\n"
					+ "Digite SIM ou NÃO");
			
			if(input.toUpperCase().equals("SIM")) {
				bool = true;
				break;
			} else if(input.toUpperCase().equals("NAO") || input.toUpperCase().equals("NÃO")) {
				bool = false;
				break;
			}	
		}
		
		return bool;
	}
	
	
	public String nomearLista() {
		
		String nomeLista = JOptionPane.showInputDialog("Escolha um nome para a lista " + (index+1));	
		return nomeLista;
		
	}
	
	
	public ArrayList<String> criarLista() {
		
		ArrayList<String> lista = new ArrayList<String>();
		
		while(true) {
			String input = JOptionPane.showInputDialog("MEGA LISTA " + totalMListas
														+ "\nLISTA " + (index+1)
														+ "\n" + nomesListas.get(index)
														+ "\nDIGITE SAIR PARA FECHAR A LISTA"
														+ "\n\nDigite um elemento da lista:");
			if(input.toUpperCase().equals("SAIR")) {
				break;
			} else if(!input.isEmpty()) {
				lista.add(input);
			}
			
			
		}
		
		return lista;
	}
	
	
	public String toString() {
		
		String stringPlural = "S"; //gramática
		if(this.megaLista.size() == 1) {
			stringPlural = "";
		}
		

		String listString =
				"A MEGA LISTA " + totalMListas 
				+" CONTÊM "	+ this.megaLista.size() //Tamanho da mega lista = número de sub-listas 
				+ " LISTA" + stringPlural + ":";
		

		for(int i = 0; i < this.megaLista.size(); i++) {
			
			listString += "\n\nLISTA "+(i+1)+": " + nomesListas.get(i); //Cabeçalho da sub-lista
			
			for(int j = 0; j < this.megaLista.get(i).size(); j++) {
				
				if(vaiNumerarListas.get(i)) {
					listString += "\n"+(j+1)+")"+this.megaLista.get(i).get(j) + " ";
				} else {
					listString += "\n-"+this.megaLista.get(i).get(j) + " ";
				}

				
			}//j
			
		}//i
		
		return listString; //Retorna string com termos + formatação
	}

}
