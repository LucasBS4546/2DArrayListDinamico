package megaListaDinamicaPackage;

public class Main {

	public static void main(String[] args) {

		Lista lista1 = new Lista();
		System.out.println(lista1);
		
		System.out.println("\n-----------------------------------------------------------------------\n");
		
		Lista lista2 = new Lista();
		System.out.println(lista2);
				
	}
	
}